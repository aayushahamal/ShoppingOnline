package com.onlineshop;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Comparator;
import java.util.stream.Collectors;

public class Main extends Application {

    private ObservableList<String> productList = FXCollections.observableArrayList();
    private ListView<String> listView = new ListView<>();
    private ComboBox<String> categoryComboBox = new ComboBox<>();
    private ComboBox<String> sortComboBox = new ComboBox<>();
    private TextField searchField = new TextField();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Online Shop");

        // Connect to SQLite database
        try {
            Connection conn = DriverManager.getConnection("jdbc:sqlite:shop.db");

            // Create UI components
            VBox mainVBox = new VBox();
            mainVBox.setPadding(new Insets(10));
            mainVBox.setStyle("-fx-background-color: #FFB6C1;"); // Light pink background
            mainVBox.setSpacing(10);

            Label titleLabel = new Label("Online Shop");
            titleLabel.setStyle("-fx-font-size: 24px; -fx-text-fill: black;"); // Black text

            HBox searchBox = new HBox();
            searchBox.setSpacing(10);

            searchField.setPromptText("Search by name");
            searchField.setStyle("-fx-prompt-text-fill: gray;");
            searchField.setOnKeyReleased(event -> searchProducts(searchField.getText()));

            categoryComboBox.getItems().addAll("All", "Food", "Electronic Devices", "Clothing");
            categoryComboBox.setValue("All");
            categoryComboBox.setOnAction(event -> filterProducts());

            sortComboBox.getItems().addAll("Rating", "Price (Low to High)", "Price (High to Low)", "Alphabetical");
            sortComboBox.setValue("Rating");
            sortComboBox.setOnAction(event -> sortProducts());

            searchBox.getChildren().addAll(new Label("Category:"), categoryComboBox,
                                            new Label("Sort by:"), sortComboBox,
                                            new Label("Search:"), searchField);

            listView.setPrefHeight(300);
            fetchProductsFromDB(conn);

            Button addButton = new Button("Add to Cart");
            addButton.setStyle("-fx-background-color: white; -fx-text-fill: black;"); // White button
            addButton.setOnAction(event -> {
                String selectedProduct = listView.getSelectionModel().getSelectedItem();
                if (selectedProduct != null) {
                    System.out.println("Added to cart: " + selectedProduct);
                }
            });

            mainVBox.getChildren().addAll(titleLabel, searchBox, listView, addButton);

            Scene scene = new Scene(mainVBox, 600, 400);
            primaryStage.setScene(scene);
            primaryStage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void fetchProductsFromDB(Connection conn) {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM products");

            productList.clear();
            while (rs.next()) {
                String product = rs.getInt("id") + ": " +
                        rs.getString("name") + " - " +
                        rs.getString("description") + " - $" +
                        rs.getDouble("price");
                productList.add(product);
            }

            rs.close();
            stmt.close();

            listView.setItems(productList);
            filterProducts(); // Apply filters initially

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void searchProducts(String searchText) {
        ObservableList<String> filteredList = FXCollections.observableArrayList();
        filteredList.addAll(productList.stream()
                .filter(product -> product.toLowerCase().contains(searchText.toLowerCase()))
                .collect(Collectors.toList()));
        listView.setItems(filteredList);
        filterProducts(); // Apply other filters after search
    }

    private void filterProducts() {
        String selectedCategory = categoryComboBox.getValue();
        ObservableList<String> filteredList = FXCollections.observableArrayList();

        if (selectedCategory.equals("All")) {
            filteredList.addAll(productList);
        } else {
            filteredList.addAll(productList.stream()
                    .filter(product -> product.contains(selectedCategory))
                    .collect(Collectors.toList()));
        }

        listView.setItems(filteredList);
        sortProducts(); // Apply sorting after filtering
    }

    private void sortProducts() {
        String sortBy = sortComboBox.getValue();

        switch (sortBy) {
            case "Rating":
                productList.sort(Comparator.comparingInt(p -> Integer.parseInt(p.split(":")[1].trim())));
                break;
            case "Price (Low to High)":
                productList.sort(Comparator.comparingDouble(p -> Double.parseDouble(p.split("\\$")[1].trim())));
                break;
            case "Price (High to Low)":
                productList.sort((p1, p2) -> Double.compare(
                        Double.parseDouble(p2.split("\\$")[1].trim()),
                        Double.parseDouble(p1.split("\\$")[1].trim())));
                break;
            case "Alphabetical":
                productList.sort(Comparator.comparing(p -> p.split(":")[1].trim()));
                break;
            default:
                break;
        }

        listView.setItems(productList);
    }

    public static void main(String[] args) {
        launch(args);
    }
}

