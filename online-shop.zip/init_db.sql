-- init_db.sql
INSERT INTO products (name, description, price, category, rating) VALUES
('High-Performance Laptop', 'Powerful laptop for gaming and design', 999.99, 'Electronic Devices', 4),
('Smartphone', 'Latest model with advanced features', 599.99, 'Electronic Devices', 5),
('T-shirt', 'Comfortable cotton t-shirt', 19.99, 'Clothing', 3),
('Jeans', 'Classic denim jeans', 39.99, 'Clothing', 4),
('Pizza', 'Delicious cheese pizza', 9.99, 'Food', 4),
('Burger', 'Juicy beef burger', 6.99, 'Food', 5);
